import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Apakah Anda memiliki kartu belanja? (1=true, 0=false): ");

        // Validate input for memilikiKartu
        while (!scanner.hasNextInt()) {
            System.out.println("Masukkan angka 1 atau 0.");
            scanner.next(); // Consume invalid input
        }
        int memilikiKartu = scanner.nextInt();

        System.out.print("Berapa total pembelanjaan Anda? ");

        // Validate input for totalPembelanjaan
        while (!scanner.hasNextInt()) {
            System.out.println("Masukkan angka.");
            scanner.next(); // Consume invalid input
        }
        int totalPembelanjaan = scanner.nextInt();

        // Tambahkan langkah untuk menghitung diskon 15rb
        if (memilikiKartu == 1 && totalPembelanjaan > 100000) {
            System.out.println("Anda mendapatkan diskon sebesar 15rb");
            totalPembelanjaan -= 15000; // Mengurangkan diskon dari total pembelanjaan
            System.out.println("Total pembelanjaan setelah diskon: " + totalPembelanjaan);
            System.out.println("Program berakhir.");
        } else if (totalPembelanjaan >= 500000) {
            // Tambahkan langkah untuk menghitung diskon 50rb
            System.out.println("Anda mendapatkan diskon sebesar 50rb");
            totalPembelanjaan -= 50000; // Mengurangkan diskon dari total pembelanjaan
            System.out.println("Total pembelanjaan setelah diskon: " + totalPembelanjaan);
            System.out.println("Program berakhir.");
        } else {
            System.out.println("Program melanjutkan ke langkah berikutnya.");
            // Tambahkan langkah-langkah berikutnya sesuai dengan kebutuhan
        }

        scanner.close();
    }
}
